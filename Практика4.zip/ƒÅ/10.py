A=int(input())
B=int(input())

fib1, fib2 = 1, 1
x = 0
y = 0

for i in range(3, A+1):
    if i <= B:
        y = fib1 + fib2

    x = fib1 + fib2
    fib1 = fib2
    fib2 = x
print(x - y)
input()