x = int(input())

fib1, fib2 = 1, 1
y = 0

for i in range(3, x+1):
    y = fib1 + fib2
    fib1 = fib2
    fib2 = y
print(y)
input()