n = int(input())
faktorial = 1
sum = 0
for i in range(1, n + 1):
    faktorial *= i
    sum += faktorial
print(sum)
input()