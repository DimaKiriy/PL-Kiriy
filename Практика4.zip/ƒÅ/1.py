a = int(input())
b = int(input())
for i in range(a, b+1):
    print(i)
input()