N=int(input())
sum=0
for i in range(N):
    a=int(input())
    sum+=a
print (sum)
input()